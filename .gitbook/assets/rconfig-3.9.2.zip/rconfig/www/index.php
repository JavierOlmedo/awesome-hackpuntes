<?php include("../config/config.inc.php");  ?>
<meta HTTP-EQUIV="REFRESH" content="0; url=<?php echo $config_basedir; ?>login.php">
