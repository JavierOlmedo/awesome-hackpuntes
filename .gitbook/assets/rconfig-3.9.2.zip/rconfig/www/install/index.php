<meta HTTP-EQUIV="REFRESH" content="0;url=/install/preinstall.php">
